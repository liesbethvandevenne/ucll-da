package org.ucll.da.entities;

public enum WeatherDataType {
	FORECAST,
	CURRENTCONDITION
}
