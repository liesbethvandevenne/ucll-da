package org.ucll.da.entities;

public interface WeatherData {

	public City getCity();
	
}
